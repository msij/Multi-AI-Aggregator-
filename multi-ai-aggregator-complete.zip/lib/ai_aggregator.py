"""
Multi-AI Model Aggregation Tool
支持豆包、千问、元宝等AI模型的聚合工具
"""

import asyncio
import json
import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from abc import ABC, abstractmethod
import requests
from bs4 import BeautifulSoup
import yaml

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class AIModelResponse:
    """AI模型响应数据结构"""
    model_name: str
    response: str
    confidence: float = 0.0
    processing_time: float = 0.0
    metadata: Dict[str, Any] = None

class AIModelInterface(ABC):
    """AI模型接口抽象类"""
    
    @abstractmethod
    async def generate_response(self, prompt: str) -> AIModelResponse:
        """生成AI响应"""
        pass
    
    @abstractmethod
    async def get_model_info(self) -> Dict[str, Any]:
        """获取模型信息"""
        pass

class DoubanAI(AIModelInterface):
    """豆包AI模型"""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key
        self.base_url = "https://api.douban.com/v1/chat"
        self.model_name = "豆包"
    
    async def generate_response(self, prompt: str) -> AIModelResponse:
        """生成豆包AI响应"""
        try:
            start_time = asyncio.get_event_loop().time()
            
            # 这里应该是实际的API调用，示例使用模拟响应
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "model": "douban-pro",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.7
            }
            
            response = requests.post(self.base_url, json=payload, headers=headers, timeout=30)
            response.raise_for_status()
            
            result = response.json()
            response_time = asyncio.get_event_loop().time() - start_time
            
            return AIModelResponse(
                model_name=self.model_name,
                response=result.get("content", ""),
                confidence=0.85,
                processing_time=response_time,
                metadata={"model": "douban-pro", "tokens_used": result.get("usage", {}).get("total_tokens", 0)}
            )
            
        except Exception as e:
            logger.error(f"豆包AI调用失败: {e}")
            return AIModelResponse(
                model_name=self.model_name,
                response=f"抱歉，豆包AI暂时无法响应: {str(e)}",
                confidence=0.0,
                processing_time=0.0
            )
    
    async def get_model_info(self) -> Dict[str, Any]:
        """获取豆包模型信息"""
        return {
            "name": self.model_name,
            "provider": "豆瓣AI",
            "version": "1.0",
            "max_tokens": 4000,
            "supports_streaming": True
        }

class QianwenAI(AIModelInterface):
    """千问AI模型"""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key
        self.base_url = "https://qianwen.aliyun.com/api/v1/chat"
        self.model_name = "千问"
    
    async def generate_response(self, prompt: str) -> AIModelResponse:
        """生成千问AI响应"""
        try:
            start_time = asyncio.get_event_loop().time()
            
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "model": "qwen-turbo",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.7
            }
            
            response = requests.post(self.base_url, json=payload, headers=headers, timeout=30)
            response.raise_for_status()
            
            result = response.json()
            response_time = asyncio.get_event_loop().time() - start_time
            
            return AIModelResponse(
                model_name=self.model_name,
                response=result.get("output", {}).get("text", ""),
                confidence=0.88,
                processing_time=response_time,
                metadata={"model": "qwen-turbo", "usage": result.get("usage", {})}
            )
            
        except Exception as e:
            logger.error(f"千问AI调用失败: {e}")
            return AIModelResponse(
                model_name=self.model_name,
                response=f"抱歉，千问AI暂时无法响应: {str(e)}",
                confidence=0.0,
                processing_time=0.0
            )
    
    async def get_model_info(self) -> Dict[str, Any]:
        """获取千问模型信息"""
        return {
            "name": self.model_name,
            "provider": "阿里巴巴",
            "version": "1.0",
            "max_tokens": 6000,
            "supports_streaming": True
        }

class YuanbaoAI(AIModelInterface):
    """元宝AI模型"""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key
        self.base_url = "https://ai.baidu.com/rpc/v2/ernie"
        self.model_name = "元宝"
    
    async def generate_response(self, prompt: str) -> AIModelResponse:
        """生成元宝AI响应"""
        try:
            start_time = asyncio.get_event_loop().time()
            
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "model": "ernie-4.0",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.7
            }
            
            response = requests.post(self.base_url, json=payload, headers=headers, timeout=30)
            response.raise_for_status()
            
            result = response.json()
            response_time = asyncio.get_event_loop().time() - start_time
            
            return AIModelResponse(
                model_name=self.model_name,
                response=result.get("result", ""),
                confidence=0.90,
                processing_time=response_time,
                metadata={"model": "ernie-4.0", "usage": result.get("usage", {})}
            )
            
        except Exception as e:
            logger.error(f"元宝AI调用失败: {e}")
            return AIModelResponse(
                model_name=self.model_name,
                response=f"抱歉，元宝AI暂时无法响应: {str(e)}",
                confidence=0.0,
                processing_time=0.0
            )
    
    async def get_model_info(self) -> Dict[str, Any]:
        """获取元宝模型信息"""
        return {
            "name": self.model_name,
            "provider": "百度",
            "version": "1.0",
            "max_tokens": 8000,
            "supports_streaming": True
        }

class WebContentScraper:
    """网页内容抓取器"""
    
    def __init__(self, user_agent: str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"):
        self.user_agent = user_agent
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": user_agent})
    
    async def scrape_content(self, url: str, timeout: int = 30) -> Dict[str, Any]:
        """抓取网页内容"""
        try:
            response = self.session.get(url, timeout=timeout)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 提取主要内容
            title = soup.find('title').get_text() if soup.find('title') else "无标题"
            
            # 移除脚本和样式
            for script in soup(["script", "style"]):
                script.decompose()
            
            # 提取文本内容
            content = soup.get_text()
            content = ' '.join(content.split())  # 清理空白
            
            return {
                "url": url,
                "title": title,
                "content": content[:5000],  # 限制长度
                "status": "success",
                "content_length": len(content)
            }
            
        except Exception as e:
            logger.error(f"网页抓取失败: {e}")
            return {
                "url": url,
                "title": "",
                "content": "",
                "status": "error",
                "error": str(e)
            }
    
    async def scrape_multiple_urls(self, urls: List[str]) -> List[Dict[str, Any]]:
        """批量抓取多个URL"""
        tasks = [self.scrape_content(url) for url in urls]
        return await asyncio.gather(*tasks)

class ResultIntegrator:
    """结果整合器"""
    
    def __init__(self):
        self.ranking_weights = {
            "confidence": 0.4,
            "processing_time": 0.2,
            "content_length": 0.3,
            "model_reliability": 0.1
        }
    
    def integrate_and_rank(self, responses: List[AIModelResponse]) -> List[AIModelResponse]:
        """整合并排序AI模型响应"""
        if not responses:
            return []
        
        # 计算每个响应的综合评分
        scored_responses = []
        for response in responses:
            score = self._calculate_score(response)
            scored_responses.append((response, score))
        
        # 按评分排序
        scored_responses.sort(key=lambda x: x[1], reverse=True)
        
        # 更新响应的综合评分
        for i, (response, score) in enumerate(scored_responses):
            response.metadata = response.metadata or {}
            response.metadata['composite_score'] = score
            response.metadata['rank'] = i + 1
        
        return [response for response, _ in scored_responses]
    
    def _calculate_score(self, response: AIModelResponse) -> float:
        """计算响应的综合评分"""
        score = 0.0
        
        # 置信度评分 (0-1)
        score += response.confidence * self.ranking_weights["confidence"]
        
        # 处理时间评分 (越快越好，但避免过快响应)
        if response.processing_time > 0:
            time_score = max(0, 1 - (response.processing_time / 10.0))  # 10秒为基准
            score += time_score * self.ranking_weights["processing_time"]
        
        # 内容长度评分 (适中的长度更好)
        content_length = len(response.response)
        if content_length > 100:  # 避免过短响应
            length_score = min(1.0, content_length / 1000.0)  # 1000字为基准
            score += length_score * self.ranking_weights["content_length"]
        
        # 模型可靠性评分
        reliability_scores = {"豆包": 0.85, "千问": 0.88, "元宝": 0.90}
        model_reliability = reliability_scores.get(response.model_name, 0.8)
        score += model_reliability * self.ranking_weights["model_reliability"]
        
        return min(1.0, score)
    
    def merge_responses(self, responses: List[AIModelResponse]) -> str:
        """合并多个AI模型响应"""
        if not responses:
            return "无有效响应"
        
        # 取前3个最佳响应
        top_responses = responses[:3]
        
        # 构建合并内容
        merged_content = f"## 多AI模型聚合结果\n\n"
        merged_content += f"基于{len(top_responses)}个AI模型的分析结果：\n\n"
        
        for i, response in enumerate(top_responses, 1):
            merged_content += f"### {i}. {response.model_name} (评分: {response.metadata.get('composite_score', 0):.2f})\n"
            merged_content += f"响应时间: {response.processing_time:.2f}秒\n"
            merged_content += f"内容:\n{response.response}\n\n"
            merged_content += "---\n\n"
        
        return merged_content

class AIModelAggregator:
    """AI模型聚合器主类"""
    
    def __init__(self, config_path: str = None):
        self.models = {}
        self.config = self._load_config(config_path)
        self.scraper = WebContentScraper()
        self.integrator = ResultIntegrator()
        
        # 初始化AI模型
        self._initialize_models()
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载配置文件"""
        if config_path and os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """获取默认配置"""
        return {
            "models": {
                "douban": {
                    "enabled": True,
                    "api_key": "",
                    "priority": 1
                },
                "qianwen": {
                    "enabled": True,
                    "api_key": "",
                    "priority": 1
                },
                "yuanbao": {
                    "enabled": True,
                    "api_key": "",
                    "priority": 1
                }
            },
            "web_scraping": {
                "enabled": True,
                "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "timeout": 30
            },
            "result_integration": {
                "max_responses": 5,
                "ranking_enabled": True,
                "merge_responses": True
            }
        }
    
    def _initialize_models(self):
        """初始化AI模型"""
        model_configs = self.config.get("models", {})
        
        if model_configs.get("douban", {}).get("enabled", False):
            api_key = model_configs["douban"].get("api_key", "")
            self.models["douban"] = DoubanAI(api_key)
        
        if model_configs.get("qianwen", {}).get("enabled", False):
            api_key = model_configs["qianwen"].get("api_key", "")
            self.models["qianwen"] = QianwenAI(api_key)
        
        if model_configs.get("yuanbao", {}).get("enabled", False):
            api_key = model_configs["yuanbao"].get("api_key", "")
            self.models["yuanbao"] = YuanbaoAI(api_key)
    
    async def generate_aggregated_response(self, prompt: str, include_web_content: bool = False) -> Dict[str, Any]:
        """生成聚合响应"""
        results = {
            "prompt": prompt,
            "model_responses": [],
            "web_content": [],
            "integrated_result": "",
            "model_stats": {}
        }
        
        # 生成各AI模型响应
        if self.models:
            tasks = [model.generate_response(prompt) for model in self.models.values()]
            responses = await asyncio.gather(*tasks, return_exceptions=True)
            
            for response in responses:
                if isinstance(response, Exception):
                    logger.error(f"模型响应异常: {response}")
                elif response:
                    results["model_responses"].append(response)
        
        # 网页内容抓取
        if include_web_content:
            web_content = await self.scraper.scrape_content(f"https://www.baidu.com/s?wd={prompt}")
            results["web_content"].append(web_content)
        
        # 整合和排序结果
        if self.config.get("result_integration", {}).get("ranking_enabled", False):
            ranked_responses = self.integrator.integrate_and_rank(results["model_responses"])
            results["model_responses"] = ranked_responses
            
            # 生成合并结果
            if self.config.get("result_integration", {}).get("merge_responses", False):
                results["integrated_result"] = self.integrator.merge_responses(ranked_responses)
        
        # 统计信息
        results["model_stats"] = {
            "total_models": len(self.models),
            "successful_responses": len(results["model_responses"]),
            "average_confidence": sum(r.confidence for r in results["model_responses"]) / max(1, len(results["model_responses"])),
            "average_processing_time": sum(r.processing_time for r in results["model_responses"]) / max(1, len(results["model_responses"]))
        }
        
        return results
    
    def get_available_models(self) -> List[str]:
        """获取可用的AI模型列表"""
        return list(self.models.keys())
    
    def switch_model(self, model_name: str, enabled: bool):
        """切换模型状态"""
        if model_name in self.config.get("models", {}):
            self.config["models"][model_name]["enabled"] = enabled
            if enabled and model_name not in self.models:
                # 启用模型
                api_key = self.config["models"][model_name].get("api_key", "")
                if model_name == "douban":
                    self.models[model_name] = DoubanAI(api_key)
                elif model_name == "qianwen":
                    self.models[model_name] = QianwenAI(api_key)
                elif model_name == "yuanbao":
                    self.models[model_name] = YuanbaoAI(api_key)
            elif not enabled and model_name in self.models:
                # 禁用模型
                del self.models[model_name]

if __name__ == "__main__":
    import os
    
    # 创建配置文件
    os.makedirs("config", exist_ok=True)
    
    # 示例使用
    async def main():
        aggregator = AIModelAggregator()
        
        print("可用的AI模型:", aggregator.get_available_models())
        
        # 测试聚合响应
        prompt = "什么是人工智能？请详细解释。"
        results = await aggregator.generate_aggregated_response(prompt, include_web_content=True)
        
        print("\n=== AI模型聚合结果 ===")
        print(f"提示: {prompt}")
        print(f"可用模型: {results['model_stats']['total_models']}")
        print(f"成功响应: {results['model_stats']['successful_responses']}")
        print(f"平均置信度: {results['model_stats']['average_confidence']:.2f}")
        print(f"平均处理时间: {results['model_stats']['average_processing_time']:.2f}秒")
        
        print("\n=== 整合结果 ===")
        print(results['integrated_result'])
    
    # 运行示例
    asyncio.run(main())