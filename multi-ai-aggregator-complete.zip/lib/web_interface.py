#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
多AI模型聚合工具 - Web界面版本
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from ai_aggregator import AIModelAggregator
import asyncio
from flask import Flask, render_template, request, jsonify
import threading
import time

app = Flask(__name__)
app.config['SECRET_KEY'] = 'ai-aggregator-secret-key'

# 全局变量
current_query = ""
current_results = {}
aggregator = None

def init_aggregator():
    """初始化聚合器"""
    global aggregator
    aggregator = AIModelAggregator()

@app.route('/')
def index():
    """首页"""
    return render_template('index.html')

@app.route('/query', methods=['POST'])
def query():
    """处理查询请求"""
    global current_query, current_results
    
    data = request.get_json()
    query = data.get('query', '')
    models = data.get('models', ['豆包', '千问', '元宝'])
    
    if not query:
        return jsonify({'error': '查询内容不能为空'}), 400
    
    try:
        # 在后台线程中执行查询
        def background_query():
            global current_results
            
            # 重置结果
            current_results = {
                'query': query,
                'models': models,
                'status': 'processing',
                'results': [],
                'start_time': time.time()
            }
            
            # 执行查询
            try:
                responses = asyncio.run(aggregator.query_multiple_models(query, models))
                
                current_results.update({
                    'status': 'completed',
                    'results': [
                        {
                            'platform': resp.platform,
                            'response': resp.response,
                            'status': resp.status,
                            'response_time': resp.response_time
                        }
                        for resp in responses
                    ],
                    'end_time': time.time()
                })
                
            except Exception as e:
                current_results.update({
                    'status': 'error',
                    'error': str(e),
                    'end_time': time.time()
                })
        
        # 启动后台线程
        thread = threading.Thread(target=background_query)
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'status': 'processing',
            'message': '查询已启动，请稍候...'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/status')
def status():
    """获取查询状态"""
    global current_results
    
    if not current_results:
        return jsonify({'status': 'idle'})
    
    return jsonify(current_results)

@app.route('/results')
def results():
    """获取查询结果"""
    global current_results
    
    if not current_results or current_results['status'] != 'completed':
        return jsonify({'error': '暂无完成的结果'}), 400
    
    # 生成整合结果
    combined = []
    for result in current_results['results']:
        if result['status'] == 'success' and result['response']:
            combined.append(f"【{result['platform']}】\n{result['response']}")
    
    combined_text = "\n\n".join(combined) if combined else "没有有效的回答"
    
    return jsonify({
        'query': current_results['query'],
        'models': current_results['models'],
        'individual_results': current_results['results'],
        'combined_result': combined_text,
        'total_time': time.time() - current_results['start_time']
    })

if __name__ == '__main__':
    # 初始化聚合器
    init_aggregator()
    
    # 创建模板目录
    template_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
    os.makedirs(template_dir, exist_ok=True)
    
    # 创建模板文件
    index_html = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>多AI模型聚合工具</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            resize: vertical;
            min-height: 100px;
        }
        .checkbox-group {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
        button:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }
        .status {
            margin-top: 20px;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
        }
        .status.processing {
            background-color: #e3f2fd;
            color: #1976d2;
        }
        .status.completed {
            background-color: #e8f5e8;
            color: #2e7d32;
        }
        .status.error {
            background-color: #ffebee;
            color: #c62828;
        }
        .results {
            margin-top: 30px;
            display: none;
        }
        .results.show {
            display: block;
        }
        .result-item {
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        .result-item h3 {
            margin-top: 0;
            color: #333;
        }
        .combined-result {
            background-color: #e8f5e8;
            padding: 20px;
            border-radius: 5px;
            margin-top: 20px;
        }
        .loading {
            display: none;
            text-align: center;
            margin: 20px 0;
        }
        .loading.show {
            display: block;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🤖 多AI模型聚合工具</h1>
        
        <div class="form-group">
            <label for="query">查询内容:</label>
            <textarea id="query" placeholder="输入你的问题，如：如何提高工作效率？"></textarea>
        </div>
        
        <div class="form-group">
            <label>选择AI模型:</label>
            <div class="checkbox-group">
                <div class="checkbox-item">
                    <input type="checkbox" id="doubao" name="models" value="豆包" checked>
                    <label for="doubao">豆包</label>
                </div>
                <div class="checkbox-item">
                    <input type="checkbox" id="qianwen" name="models" value="千问" checked>
                    <label for="qianwen">千问</label>
                </div>
                <div class="checkbox-item">
                    <input type="checkbox" id="yuanbao" name="models" value="元宝" checked>
                    <label for="yuanbao">元宝</label>
                </div>
            </div>
        </div>
        
        <button onclick="startQuery()" id="queryBtn">开始查询</button>
        
        <div class="loading" id="loading">
            <p>🔄 正在查询中，请稍候...</p>
        </div>
        
        <div class="status" id="status" style="display: none;"></div>
        
        <div class="results" id="results">
            <h2>查询结果</h2>
            <div id="individualResults"></div>
            <div class="combined-result" id="combinedResult"></div>
        </div>
    </div>

    <script>
        let queryInterval;
        
        function startQuery() {
            const query = document.getElementById('query').value;
            const models = Array.from(document.querySelectorAll('input[name="models"]:checked')).map(cb => cb.value);
            
            if (!query) {
                alert('请输入查询内容');
                return;
            }
            
            // 显示加载状态
            document.getElementById('loading').classList.add('show');
            document.getElementById('status').style.display = 'block';
            document.getElementById('status').className = 'status processing';
            document.getElementById('status').textContent = '🔄 正在查询中...';
            document.getElementById('results').classList.remove('show');
            document.getElementById('queryBtn').disabled = true;
            
            // 发送查询请求
            fetch('/query', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    query: query,
                    models: models
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'processing') {
                    // 开始轮询状态
                    pollStatus();
                }
            })
            .catch(error => {
                console.error('Error:', error);
                document.getElementById('status').className = 'status error';
                document.getElementById('status').textContent = '❌ 查询失败: ' + error.message;
                document.getElementById('loading').classList.remove('show');
                document.getElementById('queryBtn').disabled = false;
            });
        }
        
        function pollStatus() {
            queryInterval = setInterval(() => {
                fetch('/status')
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'completed') {
                        clearInterval(queryInterval);
                        showResults(data);
                    } else if (data.status === 'error') {
                        clearInterval(queryInterval);
                        document.getElementById('status').className = 'status error';
                        document.getElementById('status').textContent = '❌ 查询失败: ' + data.error;
                        document.getElementById('loading').classList.remove('show');
                        document.getElementById('queryBtn').disabled = false;
                    }
                })
                .catch(error => {
                    clearInterval(queryInterval);
                    console.error('Error polling status:', error);
                });
            }, 2000);
        }
        
        function showResults(data) {
            // 显示完成状态
            document.getElementById('status').className = 'status completed';
            document.getElementById('status').textContent = '✅ 查询完成!';
            document.getElementById('loading').classList.remove('show');
            document.getElementById('queryBtn').disabled = false;
            
            // 显示结果
            const resultsDiv = document.getElementById('results');
            const individualResultsDiv = document.getElementById('individualResults');
            const combinedResultDiv = document.getElementById('combinedResult');
            
            // 显示各个模型的结果
            let individualHTML = '';
            data.results.forEach(result => {
                const statusIcon = result.status === 'success' ? '✅' : '❌';
                individualHTML += `
                    <div class="result-item">
                        <h3>${statusIcon} ${result.platform}</h3>
                        <p><strong>响应时间:</strong> ${result.response_time}秒</p>
                        <p><strong>回答:</strong> ${result.response || '无回答'}</p>
                    </div>
                `;
            });
            individualResultsDiv.innerHTML = individualHTML;
            
            // 显示整合结果
            combinedResultDiv.innerHTML = `
                <h3>🤖 整合结果</h3>
                <p>${data.combined_result || '没有有效的回答'}</p>
            `;
            
            resultsDiv.classList.add('show');
        }
        
        // 示例问题
        const examples = [
            '如何提高工作效率？',
            'Python编程最佳实践',
            '市场分析报告',
            '人工智能发展趋势',
            '创业项目建议'
        ];
        
        // 随机显示示例问题
        document.addEventListener('DOMContentLoaded', function() {
            const queryInput = document.getElementById('query');
            if (queryInput && !queryInput.value) {
                queryInput.placeholder = `输入你的问题，如：${examples[Math.floor(Math.random() * examples.length)]}`;
            }
        });
    </script>
</body>
</html>
    """
    
    with open(os.path.join(template_dir, 'index.html'), 'w', encoding='utf-8') as f:
        f.write(index_html)
    
    # 启动Flask应用
    app.run(debug=True, host='0.0.0.0', port=5000)

if __name__ == '__main__':
    main()