# Multi AI Aggregator (多AI模型聚合) - 技能说明

一个强大的多AI模型聚合技能，支持同时调用豆包、千问、元宝等多个AI模型，智能整合回答结果。

## 功能

- 🔥 **多模型聚合**: 同时查询豆包、千问、元宝等AI平台
- 🌐 **网页自动化**: 自动化登录和访问各AI平台
- 📊 **智能整合**: 按质量和速度排序结果
- 🖥️ **Web界面**: 提供直观的查询界面
- 💻 **命令调用**: 支持命令行和对话交互
- ⚡ **并发处理**: 高效的异步查询机制

## 安装

```bash
# 安装依赖
pip install selenium requests beautifulsoup4 lxml PyYAML aiohttp

# 安装ChromeDriver
macOS: brew install chromedriver
Ubuntu: sudo apt-get install chromium-chromedriver
```

## 使用方法

### 命令用法

```bash
# 快速查询多个AI模型
openclaw multi-ai-aggregator query "如何提高工作效率？"

# 指定查询的AI模型
openclaw multi-ai-aggregator query "Python编程最佳实践" --models 豆包,千问,元宝

# 启动Web界面
openclaw multi-ai-aggregator web

# 查询状态
openclaw multi-ai-aggregator status

# 查看历史记录
openclaw multi-ai-aggregator history

# 清除缓存
openclaw multi-ai-aggregator clear
```

### 对话交互

```
你: 帮我查询一下"如何提高工作效率？"
OpenClaw: 🤖 正在同时查询豆包、千问、元宝AI模型...

你: 用豆包和千问查询即可
OpenClaw: 🎯 正在查询豆包、千问...

你: 显示Web界面
OpenClaw: 🌐 Web界面已启动，访问: http://localhost:5000
```

## 配置

### 技能配置文件 (`config/multi-ai-aggregator.yaml`)

```yaml
# 基础配置
timeout: 30
max_retries: 3
delay_between: 2

# AI模型配置
models:
  豆包:
    enabled: true
    url: "https://www.doubao.com"
    element: "textarea.input-box"
    response_class: "div.response-box"
    weight: 1.0
  千问:
    enabled: true
    url: "https://qianwen.aliyun.com"
    element: "textarea.chat-input"
    response_class: "div.message-content"
    weight: 1.0
  元宝:
    enabled: true
    url: "https://api.yuanbao168.com/v1/chat"
    method: "POST"
    response_key: "answer"
    weight: 1.0

# 输出配置
output_format: "combined"  # combined / comparison / individual
save_results: true
result_dir: "./results"

# 界面配置
web_port: 5000
web_host: "localhost"
```

## 高级用法

### 自定义模型

```bash
# 添加自定义AI模型
openclaw multi-ai-aggregator config --add-model custom_model \
  --url "https://custom.ai/api" \
  --element "textarea.query" \
  --response_class "div.response"
```

### 批量查询

```bash
# 批量查询多个问题
openclaw multi-ai-aggregator batch \
  --queries "问题1.txt,问题2.txt,问题3.txt" \
  --output "批量结果.json"
```

### 结果分析

```bash
# 分析查询结果
openclaw multi-ai-aggregator analyze "result.json"

# 生成报告
openclaw multi-ai-aggregator report "result.json" --format markdown
```

## 示例

### 示例1: 基本查询

```bash
openclaw multi-ai-aggregator query "如何提高工作效率？"
```

输出:
```
🤖 开始查询多个AI模型...
✅ 查询完成，获得3个回答:

【豆包】
提高工作效率的方法包括时间管理、任务分解、工具使用等...

【千问】
效率提升的7个关键点：1. 设定明确目标；2. 优先级排序...

【元宝】
商业角度的高效工作建议：自动化重复任务...

🤖 整合结果:
[整合后的综合答案]
```

### 示例2: Web界面

```bash
openclaw multi-ai-aggregator web
```
浏览器打开: http://localhost:5000

### 示例3: 对话交互

```
你: 用多个AI帮我分析这个项目前景
OpenClaw: 🤖 正在同时查询豆包、千问、元宝AI模型...
[获得三个AI的分析结果]
你: 把这些分析整合一下
OpenClaw: 📊 整合完成！以下是综合分析...
```

## 注意事项

- 🚫 **法律风险**: 遵守各AI平台的使用条款
- ⚠️ **技术风险**: 网页变化可能导致抓取失败
- 🔒 **隐私安全**: 不要输入敏感信息
- 🔄 **维护**: 定期更新和维护以保持兼容性

## 故障排除

### 常见问题

1. **模型访问失败**
   ```bash
   openclaw multi-ai-aggregator test --models 豆包
   ```

2. **依赖安装问题**
   ```bash
   openclaw multi-ai-aggregator install-deps
   ```

3. **配置错误**
   ```bash
   openclaw multi-ai-aggregator config --validate
   ```

### 调试模式

```bash
# 开启调试模式
openclaw multi-ai-aggregator --debug query "测试问题"
```

## 更新

```bash
# 更新技能
openclaw skills update multi-ai-aggregator

# 查看版本
openclaw multi-ai-aggregator version
```

## 技术特性

- 基于Selenium的网页自动化
- 异步并发查询机制
- 智能内容提取和整合
- 多种输出格式支持
- 完善的错误处理和重试机制

---

**提示**: 首次使用前请确保已安装所有依赖项，运行 `openclaw multi-ai-aggregator install-deps` 进行安装。