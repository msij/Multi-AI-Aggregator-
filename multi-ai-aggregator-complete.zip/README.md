# Multi AI Aggregator (多AI模型聚合)

[![Python](https://img.shields.io/badge/Python-3.7+-blue.svg)](https://python.org)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Version](https://img.shields.io/badge/Version-1.0.0-orange.svg)](#)

一个强大的OpenClaw技能，支持同时调用豆包、千问、元宝等多个AI模型，智能整合回答结果。

## 🚀 功能特性

- 🔥 **多模型聚合**: 同时查询豆包、千问、元宝等AI平台
- 🌐 **网页自动化**: 自动化登录和访问各AI平台
- 📊 **智能整合**: 按质量和速度排序结果
- 🖥️ **Web界面**: 提供直观的查询界面
- 💻 **命令调用**: 支持命令行和对话交互
- ⚡ **并发处理**: 高效的异步查询机制
- 📝 **历史记录**: 自动保存查询结果
- 🔧 **配置灵活**: 可自定义AI模型和参数

## 📦 安装

### 环境要求

- Python 3.7+
- pip3
- Chrome/Chromium 浏览器（可选，用于网页自动化）

### 安装步骤

1. **克隆仓库**
```bash
git clone https://github.com/your-username/multi-ai-aggregator-skill.git
cd multi-ai-aggregator-skill
```

2. **安装依赖**
```bash
pip3 install -r requirements.txt
```

3. **测试安装**
```bash
python3 test_skill.py
```

4. **使用技能**
```bash
# 查询多个AI模型
python3 main.py query "如何提高工作效率？"

# 指定模型
python3 main.py query "Python编程最佳实践" --models 豆包,千问

# 启动Web界面
python3 main.py web

# 查看历史记录
python3 main.py history

# 测试连接
python3 main.py test

# 查看帮助
python3 main.py --help
```

## 🎯 使用方法

### 命令行使用

```bash
# 基本查询
python3 main.py query "如何提高工作效率？"

# 指定模型
python3 main.py query "Python编程" --models 豆包,千问

# 启动Web界面
python3 main.py web
# 访问: http://localhost:5000

# 管理命令
python3 main.py history      # 查看历史
python3 main.py clear       # 清除缓存
python3 main.py test        # 测试连接
python3 main.py config      # 查看配置
python3 main.py version     # 版本信息
```

### Web界面使用

1. 启动Web界面：`python3 main.py web`
2. 浏览器访问：`http://localhost:5000`
3. 输入问题并选择AI模型
4. 查看实时查询结果

### 对话交互（OpenClaw）

```
你: 用多个AI帮我分析这个项目前景
OpenClaw: 🤖 正在同时查询豆包、千问、元宝AI模型...
[获得三个AI的分析结果]

你: 把这些分析整合一下
OpenClaw: 📊 整合完成！以下是综合分析...
```

## ⚙️ 配置

### 配置文件

编辑 `config/multi-ai-aggregator.yaml`：

```yaml
# 基础配置
timeout: 30
max_retries: 3
delay_between: 2

# AI模型配置
models:
  豆包:
    enabled: true
    url: "https://www.doubao.com"
    element: "textarea.input-box"
    response_class: "div.response-box"
    weight: 1.0
    description: "擅长中文创作、对话"
  千问:
    enabled: true
    url: "https://qianwen.aliyun.com"
    element: "textarea.chat-input"
    response_class: "div.message-content"
    weight: 1.0
    description: "技术问题、代码生成"
  元宝:
    enabled: true
    url: "https://api.yuanbao168.com/v1/chat"
    method: "POST"
    response_key: "answer"
    weight: 1.0
    description: "商业分析、文案创作"

# 输出配置
output_format: "combined"  # combined / comparison / individual
save_results: true
result_dir: "./results"

# 界面配置
web_port: 5000
web_host: "localhost"
```

### 环境变量

```bash
# 无头模式（推荐用于服务器环境）
export AI_BROWSER_HEADLESS=1

# 超时设置
export AI_TIMEOUT=30

# 最大重试次数
export AI_MAX_RETRIES=3
```

## 📊 输出格式

### 整合格式 (combined)
```
【豆包】
提高工作效率的方法包括时间管理、任务分解、工具使用等...

【千问】
效率提升的7个关键点：1. 设定明确目标；2. 优先级排序...

【元宝】
商业角度的高效工作建议：自动化重复任务...
```

### 对比格式 (comparison)
```
=== 豆包 ===
提高工作效率的方法...

=== 千问 ===
效率提升的7个关键点...

=== 元宝 ===
商业角度的高效工作建议...
```

## 🛠️ 系统要求

### 依赖项

```bash
# 基础依赖
pip3 install selenium requests beautifulsoup4 lxml PyYAML aiohttp flask flask-cors

# 浏览器（可选）
macOS: brew install --cask google-chrome
Ubuntu: sudo apt-get install google-chrome-stable

# ChromeDriver（可选）
macOS: brew install chromedriver
Ubuntu: sudo apt-get install chromium-chromedriver
```

### 开发环境

```bash
# 安装开发依赖
pip3 install pytest black flake8 mypy

# 运行测试
python3 -m pytest tests/

# 代码格式化
black .

# 代码检查
flake8 .
mypy .
```

## 🔧 故障排除

### 常见问题

1. **依赖安装失败**
```bash
pip3 install --upgrade pip
pip3 install -r requirements.txt
```

2. **浏览器访问失败**
```bash
# 检查浏览器版本
google-chrome --version

# 更新ChromeDriver
brew upgrade chromedriver
```

3. **网页元素定位失败**
```bash
# 检查页面结构
# 更新CSS选择器配置
```

### 调试模式

```bash
python3 main.py --debug query "测试问题"
```

## 📋 开发

### 项目结构

```
multi-ai-aggregator-skill/
├── SKILL.md              # 技能说明文档
├── main.py               # 技能主文件
├── README.md             # 项目说明
├── requirements.txt       # 依赖包列表
├── test_skill.py         # 测试脚本
├── install.sh            # 安装脚本
├── .gitignore            # Git忽略文件
├── config/
│   └── multi-ai-aggregator.yaml  # 配置文件
└── lib/
    ├── ai_aggregator.py  # 核心聚合工具
    └── web_interface.py  # Web界面
```

### 贡献指南

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开 Pull Request

## 📄 许可证

本项目基于 MIT 许可证开源 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 🤝 支持

- 📧 提交 Issue: [GitHub Issues](https://github.com/your-username/multi-ai-aggregator-skill/issues)
- 💬 讨论: [GitHub Discussions](https://github.com/your-username/multi-ai-aggregator-skill/discussions)
- 📖 文档: [Wiki](https://github.com/your-username/multi-ai-aggregator-skill/wiki)

## 🌟 Star History

如果这个项目对你有帮助，请给它一个 Star ⭐

## 📝 更新日志

### v1.0.0 (2024-02-26)
- 初始版本发布
- 支持豆包、千问、元宝三个AI模型
- 实现网页自动化和API调用
- 提供命令行和Web界面
- 支持结果智能整合

---

**Made with ❤️ by [Your Name](https://github.com/your-username)**