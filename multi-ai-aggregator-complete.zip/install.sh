#!/bin/bash
# Multi AI Aggregator 技能安装脚本

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_NAME="multi-ai-aggregator"

echo "🤖 Multi AI Aggregator 技能安装"
echo "==============================="

# 检查是否在技能目录
if [ ! -f "${SCRIPT_DIR}/main.py" ]; then
    echo "❌ 错误: 请在技能目录中运行此脚本"
    exit 1
fi

# 检查Python环境
echo "📦 检查Python环境..."
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 未安装，请先安装 Python3"
    exit 1
fi

# 安装Python依赖
echo "📥 安装Python依赖..."
pip3 install -r "${SCRIPT_DIR}/requirements.txt"

# 检查Chrome/Chromium
echo "🌐 检查浏览器环境..."
if command -v google-chrome &> /dev/null; then
    BROWSER="google-chrome"
    echo "✅ 使用 Google Chrome"
elif command -v chromium &> /dev/null; then
    BROWSER="chromium"
    echo "✅ 使用 Chromium"
elif command -v chrome &> /dev/null; then
    BROWSER="chrome"
    echo "✅ 使用 Chrome"
else
    echo "⚠️ 未找到Chrome/Chromium，建议安装以支持网页自动化"
    echo "   macOS: brew install --cask google-chrome"
    echo "   Ubuntu: sudo apt-get install google-chrome-stable"
    echo "   或设置 AI_BROWSER_HEADLESS=1 使用无头模式"
fi

# 检查ChromeDriver
echo "🔧 检查ChromeDriver..."
if command -v chromedriver &> /dev/null; then
    echo "✅ ChromeDriver已安装"
else
    echo "⚠️ ChromeDriver未安装，请安装以支持网页自动化"
    echo "   macOS: brew install chromedriver"
    echo "   Ubuntu: sudo apt-get install chromium-chromedriver"
    echo "   或设置 AI_BROWSER_HEADLESS=1 使用无头模式"
fi

# 创建命令行工具
echo "🔗 创建命令行工具..."
cat > "${SCRIPT_DIR}/multi-ai-aggregator" << 'EOF'
#!/usr/bin/env python3
# Multi AI Aggregator 命令行工具

import sys
import os

# 添加技能路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from main import main

if __name__ == "__main__":
    main()
EOF

chmod +x "${SCRIPT_DIR}/multi-ai-aggregator"

# 创建符号链接（可选）
if command -v openclaw &> /dev/null; then
    echo "🔗 创建OpenClaw命令符号链接..."
    if [ ! -L "/usr/local/bin/openclaw-multi-ai-aggregator" ]; then
        ln -sf "${SCRIPT_DIR}/multi-ai-aggregator" /usr/local/bin/openclaw-multi-ai-aggregator
        echo "✅ 创建符号链接: /usr/local/bin/openclaw-multi-ai-aggregator"
    fi
fi

# 测试安装
echo "🧪 测试安装..."
if python3 "${SCRIPT_DIR}/multi-ai-aggregator" --version > /dev/null 2>&1; then
    echo "✅ 安装成功！"
else
    echo "❌ 安装失败，请检查错误信息"
    exit 1
fi

echo ""
echo "🎯 使用方法:"
echo ""
echo "命令行:"
echo "  ${SCRIPT_DIR}/multi-ai-aggregator query \"如何提高工作效率？\""
echo "  ${SCRIPT_DIR}/multi-ai-aggregator web"
echo "  ${SCRIPT_DIR}/multi-ai-aggregator history"
echo ""
echo "OpenClaw集成:"
echo "  openclaw multi-ai-aggregator query \"你的问题\""
echo ""
echo "📖 更多信息请查看 SKILL.md"