#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Multi AI Aggregator - OpenClaw 技能主文件
多AI模型聚合技能，支持同时调用豆包、千问、元宝等AI模型
"""

import os
import sys
import json
import logging
import asyncio
import argparse
from pathlib import Path
from typing import Dict, List, Optional, Any
import time

# 添加技能路径到Python路径
SKILL_DIR = Path(__file__).parent
sys.path.append(str(SKILL_DIR))
sys.path.append(str(SKILL_DIR / "lib"))

try:
    from ai_aggregator import AIModelAggregator
except ImportError:
    print("⚠️ 依赖模块未找到，请先安装依赖")
    sys.exit(1)

class MultiAIAggregatorSkill:
    """多AI模型聚合技能"""
    
    def __init__(self):
        self.skill_dir = SKILL_DIR
        self.config_dir = self.skill_dir / "config"
        self.result_dir = self.skill_dir / "results"
        self.aggregator = None
        self.config = self.load_config()
        self.setup_logging()
        
        # 确保目录存在
        self.result_dir.mkdir(exist_ok=True)
        
    def setup_logging(self):
        """设置日志"""
        log_file = self.skill_dir / "multi_ai_aggregator.log"
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
    def load_config(self) -> Dict[str, Any]:
        """加载配置文件"""
        config_file = self.config_dir / "multi-ai-aggregator.yaml"
        if not config_file.exists():
            self.create_default_config(config_file)
            
        try:
            import yaml
            with open(config_file, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            self.logger.error(f"加载配置失败: {e}")
            return self.get_default_config()
    
    def create_default_config(self, config_file: Path):
        """创建默认配置文件"""
        config_content = """
# Multi AI Aggregator 配置文件

# 基础配置
timeout: 30
max_retries: 3
delay_between: 2

# AI模型配置
models:
  豆包:
    enabled: true
    url: "https://www.doubao.com"
    element: "textarea.input-box"
    response_class: "div.response-box"
    weight: 1.0
  千问:
    enabled: true
    url: "https://qianwen.aliyun.com"
    element: "textarea.chat-input"
    response_class: "div.message-content"
    weight: 1.0
  元宝:
    enabled: true
    url: "https://api.yuanbao168.com/v1/chat"
    method: "POST"
    response_key: "answer"
    weight: 1.0

# 输出配置
output_format: "combined"
save_results: true
result_dir: "./results"

# 界面配置
web_port: 5000
web_host: "localhost"
"""
        
        config_file.parent.mkdir(parents=True, exist_ok=True)
        with open(config_file, 'w', encoding='utf-8') as f:
            f.write(config_content)
        
        self.logger.info(f"创建默认配置文件: {config_file}")
    
    def get_default_config(self) -> Dict[str, Any]:
        """获取默认配置"""
        return {
            "timeout": 30,
            "max_retries": 3,
            "delay_between": 2,
            "models": {
                "豆包": {"enabled": True, "weight": 1.0},
                "千问": {"enabled": True, "weight": 1.0},
                "元宝": {"enabled": True, "weight": 1.0}
            },
            "output_format": "combined",
            "save_results": True,
            "result_dir": "./results",
            "web_port": 5000,
            "web_host": "localhost"
        }
    
    def get_enabled_models(self) -> List[str]:
        """获取启用的模型列表"""
        return [name for name, config in self.config.get("models", {}).items() 
                if config.get("enabled", True)]
    
    async def query_ai_models(self, query: str, models: List[str] = None) -> Dict[str, Any]:
        """查询多个AI模型"""
        if models is None:
            models = self.get_enabled_models()
        
        self.logger.info(f"开始查询: {query}")
        self.logger.info(f"目标模型: {models}")
        
        # 初始化聚合器
        if not self.aggregator:
            self.aggregator = AIModelAggregator(str(self.config_dir / "multi-ai-aggregator.yaml"))
        
        try:
            # 查询多个模型
            responses = await self.aggregator.query_multiple_models(query, models)
            
            # 整合结果
            combined_result = self.aggregator.combine_responses()
            
            # 准备返回结果
            result = {
                "query": query,
                "models": models,
                "timestamp": time.time(),
                "responses": [
                    {
                        "platform": resp.platform,
                        "response": resp.response,
                        "status": resp.status,
                        "response_time": resp.response_time,
                        "confidence": resp.confidence
                    }
                    for resp in responses
                ],
                "combined_result": combined_result,
                "success_count": len([r for r in responses if r.status == "success"])
            }
            
            # 保存结果
            if self.config.get("save_results", True):
                await self.save_result(result)
            
            return result
            
        except Exception as e:
            self.logger.error(f"查询失败: {e}")
            return {
                "query": query,
                "error": str(e),
                "timestamp": time.time()
            }
        
        finally:
            # 按需关闭
            if self.aggregator:
                self.aggregator.close()
                self.aggregator = None
    
    async def save_result(self, result: Dict[str, Any]):
        """保存查询结果"""
        timestamp = int(time.time())
        filename = f"query_{timestamp}.json"
        result_file = self.result_dir / filename
        
        try:
            with open(result_file, 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            self.logger.info(f"结果已保存: {result_file}")
        except Exception as e:
            self.logger.error(f"保存结果失败: {e}")
    
    def start_web_interface(self):
        """启动Web界面"""
        try:
            from web_interface import app
            
            # 更新配置
            app.config['AGGREGATOR_CONFIG'] = self.config
            app.config['RESULT_DIR'] = str(self.result_dir)
            
            host = self.config.get("web_host", "localhost")
            port = self.config.get("web_port", 5000)
            
            print(f"🌐 Web界面启动中...")
            print(f"访问地址: http://{host}:{port}")
            print(f"按 Ctrl+C 停止服务")
            
            app.run(host=host, port=port, debug=True)
            
        except ImportError:
            print("⚠️ Web界面模块未找到")
        except Exception as e:
            print(f"❌ Web界面启动失败: {e}")
    
    def show_history(self, limit: int = 10):
        """显示历史记录"""
        try:
            results = []
            for file in sorted(self.result_dir.glob("query_*.json"))[-limit:]:
                with open(file, 'r', encoding='utf-8') as f:
                    result = json.load(f)
                    results.append(result)
            
            if not results:
                print("📭 暂无历史记录")
                return
            
            print(f"📊 最近 {len(results)} 条历史记录:")
            print("-" * 50)
            
            for i, result in enumerate(results, 1):
                timestamp = result.get("timestamp", time.time())
                time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(timestamp))
                
                print(f"{i}. [{time_str}] {result.get('query', '未知问题')}")
                print(f"   模型: {', '.join(result.get('models', []))}")
                print(f"   成功: {result.get('success_count', 0)}/{len(result.get('models', []))}")
                print()
                
        except Exception as e:
            print(f"❌ 读取历史记录失败: {e}")
    
    def clear_cache(self):
        """清除缓存"""
        try:
            files = list(self.result_dir.glob("query_*.json"))
            for file in files:
                file.unlink()
            
            print(f"🗑️ 已清除 {len(files)} 个缓存文件")
            
        except Exception as e:
            print(f"❌ 清除缓存失败: {e}")
    
    def test_models(self, models: List[str] = None):
        """测试模型连接"""
        if models is None:
            models = self.get_enabled_models()
        
        print(f"🧪 测试模型连接: {models}")
        
        async def test_query():
            result = await self.query_ai_models("测试连接", models)
            
            if "error" in result:
                print(f"❌ 测试失败: {result['error']}")
            else:
                print(f"✅ 测试成功！获得 {result.get('success_count', 0)} 个回答")
                
                for resp in result.get("responses", []):
                    status = "✅" if resp["status"] == "success" else "❌"
                    print(f"  {status} {resp['platform']}: {resp['response_time']:.1f}秒")
        
        asyncio.run(test_query())
    
    def print_version(self):
        """打印版本信息"""
        version = "1.0.0"
        print(f"🤖 Multi AI Aggregator v{version}")
        print(f"技能目录: {self.skill_dir}")
        print(f"结果目录: {self.result_dir}")
    
    def print_help(self):
        """打印帮助信息"""
        help_text = """
Multi AI Aggregator - 多AI模型聚合技能

用法:
  openclaw multi-ai-aggregator [选项]

命令:
  query <问题>        查询多个AI模型
  query <问题> --models 模型1,模型2  指定模型查询
  web                 启动Web界面
  history             查看历史记录
  status              查看状态
  clear               清除缓存
  test                测试模型连接
  install-deps        安装依赖
  config              查看配置
  version             版本信息
  help                帮助信息

示例:
  openclaw multi-ai-aggregator query "如何提高工作效率？"
  openclaw multi-ai-aggregator query "Python编程" --models 豆包,千问
  openclaw multi-ai-aggregator web
"""
        print(help_text)

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='Multi AI Aggregator - 多AI模型聚合技能')
    parser.add_argument('command', nargs='?', help='命令')
    parser.add_argument('args', nargs='*', help='参数')
    parser.add_argument('--models', help='指定模型，逗号分隔')
    parser.add_argument('--output', help='输出文件')
    parser.add_argument('--format', choices=['combined', 'comparison', 'individual'], 
                       default='combined', help='输出格式')
    parser.add_argument('--debug', action='store_true', help='调试模式')
    
    skill = MultiAIAggregatorSkill()
    
    # 解析参数
    args = parser.parse_args()
    
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # 处理命令
    if args.command is None:
        skill.print_help()
        return
    
    try:
        if args.command == "query":
            query = ' '.join(args.args)
            if not query:
                print("❌ 请提供查询问题")
                return
            
            models = None
            if args.models:
                models = [m.strip() for m in args.models.split(',')]
            
            # 执行查询
            result = asyncio.run(skill.query_ai_models(query, models))
            
            # 显示结果
            if "error" in result:
                print(f"❌ 查询失败: {result['error']}")
            else:
                print(f"✅ 查询完成！获得 {result.get('success_count', 0)} 个回答")
                
                # 显示整合结果
                if args.format == "individual":
                    print("\n" + "=" * 50)
                    print("📋 各个模型回答:")
                    print("=" * 50)
                    for resp in result.get('responses', []):
                        print(f"\n【{resp['platform']}】")
                        print(f"响应时间: {resp['response_time']:.1f}秒")
                        if resp['response']:
                            print(f"回答: {resp['response'][:200]}...")
                else:
                    print("\n" + "=" * 50)
                    print("🤖 整合结果:")
                    print("=" * 50)
                    print(result.get('combined_result', '无回答'))
        
        elif args.command == "web":
            skill.start_web_interface()
        
        elif args.command == "history":
            skill.show_history()
        
        elif args.command == "clear":
            skill.clear_cache()
        
        elif args.command == "test":
            models = None
            if args.models:
                models = [m.strip() for m in args.models.split(',')]
            skill.test_models(models)
        
        elif args.command == "install-deps":
            print("📦 安装依赖...")
            os.system(f"pip install -r {skill.skill_dir}/requirements.txt")
        
        elif args.command == "config":
            print("⚙️ 当前配置:")
            import yaml
            print(yaml.dump(skill.config, default_flow_style=False, allow_unicode=True))
        
        elif args.command == "version":
            skill.print_version()
        
        elif args.command == "help":
            skill.print_help()
        
        else:
            print(f"❌ 未知命令: {args.command}")
            skill.print_help()
    
    except KeyboardInterrupt:
        print("\n⏹️ 操作已停止")
    except Exception as e:
        print(f"❌ 执行失败: {e}")
        if args.debug:
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    main()