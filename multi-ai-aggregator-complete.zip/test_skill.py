#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Multi AI Aggregator 技能测试脚本
"""

import sys
import os
import subprocess

def test_skill():
    """测试技能功能"""
    skill_dir = "/usr/local/lib/node_modules/openclaw/skills/multi-ai-aggregator"
    
    print("🧪 Multi AI Aggregator 技能测试")
    print("=" * 40)
    
    # 测试1: 检查技能文件
    print("1. 检查技能文件...")
    required_files = [
        "SKILL.md",
        "main.py", 
        "README.md",
        "requirements.txt",
        "install.sh",
        "config/multi-ai-aggregator.yaml"
    ]
    
    missing_files = []
    for file in required_files:
        file_path = os.path.join(skill_dir, file)
        if os.path.exists(file_path):
            print(f"   ✅ {file}")
        else:
            print(f"   ❌ {file}")
            missing_files.append(file)
    
    if missing_files:
        print(f"\n❌ 缺少文件: {missing_files}")
        return False
    
    # 测试2: 检查Python模块
    print("\n2. 检查Python模块...")
    try:
        sys.path.insert(0, skill_dir)
        sys.path.insert(0, os.path.join(skill_dir, "lib"))
        
        from main import MultiAIAggregatorSkill
        print("   ✅ 主模块导入成功")
        
        # 测试配置加载
        skill = MultiAIAggregatorSkill()
        print("   ✅ 配置加载成功")
        print(f"   📋 启用的模型: {skill.get_enabled_models()}")
        
    except ImportError as e:
        print(f"   ❌ 模块导入失败: {e}")
        return False
    except Exception as e:
        print(f"   ❌ 配置加载失败: {e}")
        return False
    
    # 测试3: 检查依赖
    print("\n3. 检查依赖包...")
    try:
        import selenium
        import requests
        import yaml
        print("   ✅ 基础依赖包正常")
    except ImportError as e:
        print(f"   ⚠️ 依赖包缺失: {e}")
        print("   运行: pip install -r requirements.txt")
    
    # 测试4: 命令行工具
    print("\n4. 检查命令行工具...")
    try:
        result = subprocess.run([
            "python3", os.path.join(skill_dir, "main.py"), "--help"
        ], capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0:
            print("   ✅ 命令行工具正常")
        else:
            print("   ❌ 命令行工具异常")
            print(f"   错误: {result.stderr}")
            
    except subprocess.TimeoutExpired:
        print("   ❌ 命令行工具超时")
    except Exception as e:
        print(f"   ❌ 命令行工具测试失败: {e}")
    
    # 测试5: 版本信息
    print("\n5. 检查版本信息...")
    try:
        result = subprocess.run([
            "python3", os.path.join(skill_dir, "main.py"), "version"
        ], capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0:
            print("   ✅ 版本信息:")
            print(f"   {result.stdout.strip()}")
        else:
            print("   ❌ 版本信息获取失败")
            
    except Exception as e:
        print(f"   ⚠️ 版本信息检查失败: {e}")
    
    print("\n" + "=" * 40)
    print("✅ 测试完成!")
    
    return True

def main():
    """主函数"""
    if test_skill():
        print("\n🎉 技能安装成功！可以开始使用了。")
        print("\n📖 使用方法:")
        print("  openclaw multi-ai-aggregator query \"如何提高工作效率？\"")
        print("  openclaw multi-ai-aggregator web")
        print("  openclaw multi-ai-aggregator --help")
    else:
        print("\n❌ 测试失败，请检查安装。")
        sys.exit(1)

if __name__ == "__main__":
    main()